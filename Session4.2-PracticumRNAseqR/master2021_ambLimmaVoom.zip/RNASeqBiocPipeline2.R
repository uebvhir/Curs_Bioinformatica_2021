
##Load the data
library("airway")

#to find out where on your computer the files from a package have been installed.
indir <- system.file("extdata", package="airway", mustWork=TRUE)
list.files(indir)

#read the targets file of the experiment
csvfile <- file.path(indir, "sample_table.csv")
sampleTable <- read.csv(csvfile, row.names = 1)
sampleTable

##store the bam files in object filenames
filenames <- file.path(indir, paste0(sampleTable$Run, "_subset.bam"))
file.exists(filenames)
filenames

##Indicate that these are bam files
library("Rsamtools")
bamfiles <- BamFileList(filenames, yieldSize=2000000)


##Defining gene models
library("GenomicFeatures")

gtffile <- file.path(indir,"Homo_sapiens.GRCh37.75_subset.gtf")
txdb <- makeTxDbFromGFF(gtffile, format = "gtf", circ_seqs = character())
txdb

##resume the exons by gene
ebg <- exonsBy(txdb, by="gene")
ebg

##Generating count Matrices
library("GenomicAlignments")

se <- summarizeOverlaps(features=ebg, reads=bamfiles,
                        mode="Union",
                        singleEnd=FALSE,
                        ignore.strand=TRUE,
                        fragments=TRUE )

##See the count matrix
se
assay(se)

#dimensions of the count matrix
dim(se)

#############################################################################
##START FROM THE COMPLETE DATA (airway)
#############################################################################
data("airway")
se <- airway
dim(se)


#reorder the levels 
library(magrittr)
se$dex %<>% relevel("untrt")
se$dex

##Milions of fragments aligned to the genes
round( colSums(assay(se)) / 1e6, 1 )

##Check that the object is correct
colData(se)
#############################################################################
##START FROM THE COMPLETE DATA (gse)
#############################################################################
data(gse)
gse$cell <- gse$donor
gse$dex <- gse$condition
levels(gse$dex) <- c("untrt", "trt")

##Make a DESeqDataSet object
library("DESeq2")

# dds <- DESeqDataSet(gse, design = ~ cell + dex)
dds <- DESeqDataSet(gse, design = ~ cell + dex)


##Filter out those rows without any count
nrow(dds)
dds <- dds[ rowSums(counts(dds)) > 1, ]
nrow(dds)

##variance stabilizing transformation?(VST)
vsd <- vst(dds, blind = FALSE)
head(assay(vsd), 3)


##Sample distances.
sampleDists <- dist(t(assay(vsd)))
sampleDists

##Heatmap + Hierarchical clustering
library("pheatmap")
library("RColorBrewer")

sampleDistMatrix <- as.matrix( sampleDists )
rownames(sampleDistMatrix) <- paste( vsd$dex, vsd$cell, sep = " - " )
colnames(sampleDistMatrix) <- paste( vsd$dex, vsd$cell, sep = " - " )
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows = sampleDists,
         clustering_distance_cols = sampleDists,
         col = colors)

##Principal Component Analysis Plot
plotPCA(vsd, intgroup = c("dex", "cell"))
pcaData <- plotPCA(vsd, intgroup = c( "dex", "cell"), returnData = TRUE)
percentVar <- round(100 * attr(pcaData, "percentVar"))
library(ggplot2)
ggplot(pcaData, aes(x = PC1, y = PC2, color = dex, shape = cell)) +
  geom_point(size =3) +
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  coord_fixed() +
  ggtitle("PCA with VST data")

##Differential Expression Analysis
dds <- DESeq(dds)

##building results table
res <- results(dds, contrast=c("dex","trt","untrt"))

##Toptable
head(res[order(res$padj),])

##Information about the columns of the results table
mcols(res, use.names = TRUE)

summary(res)

#results for other comparisons
results(dds, contrast = c("cell", "N061011", "N61311"))

#volcano plot
par(mar=c(5,5,5,5), cex=1.0, cex.main=1.4, cex.axis=1.4, cex.lab=1.4)
topT <- as.data.frame(res)
#Adjusted P values (FDR Q values)
with(topT, plot(log2FoldChange, -log10(padj), pch=20, main="Volcano plot",
                cex=1.0, xlab=bquote(~Log[2]~fold~change), ylab=bquote(~-
                                                                         log[10]~Q~value)))
with(subset(topT, padj<0.05 & abs(log2FoldChange)>2),
     points(log2FoldChange, -log10(padj), pch=20, col="red", cex=0.5))
#Add lines for absolute FC>2 and P-value cut-off at FDR Q<0.05
abline(v=0, col="black", lty=3, lwd=1.0)
abline(v=-2, col="black", lty=4, lwd=2.0)
abline(v=2, col="black", lty=4, lwd=2.0)
abline(h=-log10(max(topT$pvalue[topT$padj<0.05], na.rm=TRUE)),
       col="black", lty=4, lwd=2.0)



##Subset the significant genes with strongest downregulation
# resSig <- subset(res, padj < 0.1)
# head(resSig[ order(resSig$log2FoldChange), ])
# 
# ##Subset the significant genes with strongest upregulation
# head(resSig[ order(resSig$log2FoldChange, decreasing = TRUE), ])


##Heatmap of genes
library("genefilter")
topVarGenes <- head(order(rowVars(assay(vsd)), decreasing = TRUE), 20)

mat  <- assay(vsd)[topVarGenes, ]
mat  <- mat - rowMeans(mat)
anno <- as.data.frame(colData(vsd)[, c("cell","dex")])
pheatmap(mat, annotation_col = anno)


##Results annotation
library("AnnotationDbi")
library("org.Hs.eg.db")
ens.str <- substr(rownames(res), 1, 15)
res$symbol <- mapIds(org.Hs.eg.db,
                     keys=ens.str,
                     column="SYMBOL",
                     keytype="ENSEMBL",
                     multiVals="first")
res$entrez <- mapIds(org.Hs.eg.db,
                     keys=ens.str,
                     column="ENTREZID",
                     keytype="ENSEMBL",
                     multiVals="first")

#aixo seria amb el data(airway) enlloc del data(gse):
# res$symbol <- mapIds(org.Hs.eg.db,
#                      keys=row.names(res),
#                      column="SYMBOL",
#                      keytype="ENSEMBL",
#                      multiVals="first")
# 
# res$entrez <- mapIds(org.Hs.eg.db,
#                      keys=row.names(res),
#                      column="ENTREZID",
#                      keytype="ENSEMBL",
#                      multiVals="first")


resOrdered <- res[order(res$pvalue),]
head(resOrdered)

##Exporting the results
resOrderedDF <- as.data.frame(resOrdered)[1:100, ]
write.csv(resOrderedDF, file = "results.csv")
